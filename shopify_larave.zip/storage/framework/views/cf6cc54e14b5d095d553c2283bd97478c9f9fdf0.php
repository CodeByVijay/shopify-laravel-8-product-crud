<form method="GET" action="<?php echo e(route('home')); ?>">
    <input type="text" name="shop"/>
    <button type="submit">Submit</button>
 </form>
<?php /**PATH /home/chhabicl/shopify.vijayamule.in/resources/views/login.blade.php ENDPATH**/ ?>