<form method="GET" action="<?php echo e(route('home')); ?>">
    <input type="text" name="shop"/>
    <button type="submit">Submit</button>
 </form>
<?php /**PATH /var/www/html/shopify_laravel_app/resources/views/login.blade.php ENDPATH**/ ?>